package br.edu.iserj.jogodavelha_final_uptdate

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import br.edu.iserj.jogodavelha_final_uptdate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val humano = binding.buttonhumano
        val maquina = binding.buttonmaquina
        humano.setOnClickListener{
            val intent = Intent(this, humano::class.java)
            startActivity(intent)
            finish()
        }
        maquina.setOnClickListener {
            val intent = Intent(this, humano::class.java)
            startActivity(intent)
            finish()
        }
    }
}